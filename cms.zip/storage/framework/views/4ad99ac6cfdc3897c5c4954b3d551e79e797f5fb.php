<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://cdn.tailwindcss.com"></script>
        <title>Wypożyczalnia</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;600&display=swap" rel="stylesheet">
<!--

        <style>
            html, body {
                background-color: #4c4c4c;
                color: white;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                padding: 0;
                margin: 0;
            }
            .section{
                width: 100%;
                height: 100vh;
            }



        </style>
    </head>-->
    <section class="px-6 py-4">
        <nav>
            <div>
                <a href="/"><img src="/images/logo.png"/></a>
            </div>
            <div></div>
        </nav>
    </section>
</html>
<?php /**PATH C:\xampp\htdocs\cms\resources\views/index.blade.php ENDPATH**/ ?>