
<x-layout>

    @include('_header')
    <main class="max-w-6xl mx-auto mt-6 lg:mt-20 space-y-6">
        <div class="lg:grid lg:grid-cols-4 md:grid md:grid-cols-2">
            <x-movie-card></x-movie-card>
            <x-movie-card></x-movie-card>
            <x-movie-card></x-movie-card>
            <x-movie-card></x-movie-card>
            <x-movie-card></x-movie-card>
        </div>
    </main>
</x-layout>
